package com.customerdao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Customer;
import com.repository.CustomerRepository;
import com.repository.UserRepository;



@Service
public class CustomerDaoImpl implements CustomerDao {
	@AutoWired 
	CustomerRepository customerRepository;
	@Autowired
	UserRepository userRepository;
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		
		List<Customer>  list = customerRepository.findAll();
		return null;
}
}