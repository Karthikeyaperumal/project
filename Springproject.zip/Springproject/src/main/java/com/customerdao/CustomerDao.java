package com.customerdao;
import java.util.List;

import org.springframework.stereotype.Service;

import com.entity.Customer;


@Service
public interface CustomerDao {
	public List<Customer> getAllCustomers();
}
