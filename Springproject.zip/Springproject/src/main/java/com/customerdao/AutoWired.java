package com.customerdao;

public @interface AutoWired {

}
